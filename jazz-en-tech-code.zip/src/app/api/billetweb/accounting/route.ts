// PATH: src/app/api/billetweb/accounting/route.ts
import { NextRequest, NextResponse } from 'next/server'

const BASE = 'https://www.billetweb.fr/api'

function creds() {
  return { user: process.env.BILLETWEB_USER, key: process.env.BILLETWEB_KEY }
}

// GET /api/billetweb/accounting?start=YYYY-MM-DD&end=YYYY-MM-DD&edition=...
// Source: /api/attendees (historique complet, total calé sur Billetweb)
export async function GET(req: NextRequest) {
  const { user, key } = creds()
  if (!user || !key) {
    return NextResponse.json({ error: 'BILLETWEB_USER / BILLETWEB_KEY manquants' }, { status: 500 })
  }

  const { searchParams } = new URL(req.url)
  const startStr = searchParams.get('start') || '2022-01-01'
  const endStr = searchParams.get('end') || '2030-12-31'
  const edition = searchParams.get('edition') || '' // filtre par event_name
  const auth = `user=${user}&key=${key}&version=1`

  try {
    // Participants (toutes éditions, tout l'historique)
    const res = await fetch(`${BASE}/attendees?${auth}`, { headers: { Accept: 'application/json' } })
    const data = await res.json().catch(() => null)
    if (!res.ok || (data && data.error)) {
      return NextResponse.json(
        { error: `Billetweb attendees: ${data?.description || res.status}` },
        { status: 502 }
      )
    }
    const attendees: any[] = Array.isArray(data) ? data : []

    // Liste des éditions disponibles (pour le filtre)
    const editions = [...new Set(attendees.map((a) => (a.event_name || '').trim()).filter(Boolean))].sort().reverse()

    const startD = startStr
    const endD = endStr

    const rows: any[] = []
    const totals = { brut: 0, count: 0, saleCount: 0, passCount: 0, freeCount: 0 }

    for (const a of attendees) {
      // On ne compte que les commandes payées
      if (String(a.order_paid) !== '1') continue

      const eventName = (a.event_name || '').trim()
      if (edition && eventName !== edition) continue

      // Filtre période sur la date de commande (YYYY-MM-DD)
      const orderDate = (a.order_date || a.last_update || '').slice(0, 10)
      if (orderDate && (orderDate < startD || orderDate > endD)) continue

      const price = parseFloat(a.price ?? '0') || 0
      const isPass = String(a.pass) === '1'

      let kind: 'pass' | 'sale' | 'free' = 'sale'
      if (isPass) kind = 'pass'
      else if (price === 0) kind = 'free'

      rows.push({
        date: (a.order_date || '').slice(0, 16),
        eventName,
        concert: (a.category || '').trim(),
        ticket: (a.ticket || '').trim(),
        buyer: `${a.order_firstname || ''} ${a.order_name || ''}`.trim(),
        email: a.order_email || a.email || '',
        channel: a.order_payment_type || '',
        kind,
        price,
      })

      totals.brut += price
      totals.count += 1
      if (kind === 'pass') totals.passCount += 1
      else if (kind === 'free') totals.freeCount += 1
      else totals.saleCount += 1
    }

    // tri par date décroissante
    rows.sort((x, y) => (x.date < y.date ? 1 : -1))

    // Virements reçus (payouts)
    const payRes = await fetch(`${BASE}/payouts?${auth}`, { headers: { Accept: 'application/json' } })
    const payData = await payRes.json().catch(() => null)
    const payouts: any[] = Array.isArray(payData) ? payData : []
    const payoutRows = payouts.map((p) => ({
      date: p.date || '',
      amount: parseFloat(p.amount ?? '0') || 0,
      account: p.account || '',
      iban: p.iban || '',
      swift: p.swift || '',
    }))
    const payoutTotal = payoutRows.reduce((s, p) => s + p.amount, 0)

    return NextResponse.json({
      period: { start: startStr, end: endStr },
      editions,
      rows,
      totals,
      payouts: payoutRows,
      payoutTotal,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
