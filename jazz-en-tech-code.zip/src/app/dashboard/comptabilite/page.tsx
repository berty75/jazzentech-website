// PATH: src/app/dashboard/comptabilite/page.tsx
'use client'

import { useState } from 'react'
import { Loader2, Download, RefreshCw } from 'lucide-react'
import DashboardShell from '@/components/DashboardShell'
import DatePicker from '@/components/DatePicker'

type Row = {
  date: string; eventName: string; concert: string; ticket: string
  buyer: string; email: string; channel: string
  kind: 'pass' | 'sale' | 'free'; price: number
}
type Payout = { date: string; amount: number; account: string; iban: string; swift: string }
type Totals = { brut: number; count: number; saleCount: number; passCount: number; freeCount: number }

const eur = (n: number) => n.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })
const iso = (d: Date) => {
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

export default function ComptabilitePage() {
  const today = new Date()
  const todayIso = iso(today)

  const [start, setStart] = useState('2022-01-01')
  const [end, setEnd] = useState(todayIso)
  const [edition, setEdition] = useState('')
  const [editions, setEditions] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [rows, setRows] = useState<Row[]>([])
  const [totals, setTotals] = useState<Totals | null>(null)
  const [payouts, setPayouts] = useState<Payout[]>([])
  const [payoutTotal, setPayoutTotal] = useState(0)

  const load = async () => {
    setLoading(true)
    setError('')
    try {
      const q = new URLSearchParams({ start, end })
      if (edition) q.set('edition', edition)
      const res = await fetch(`/api/billetweb/accounting?${q.toString()}`)
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'Erreur'); return }
      setRows(data.rows || [])
      setTotals(data.totals || null)
      setEditions(data.editions || [])
      setPayouts(data.payouts || [])
      setPayoutTotal(data.payoutTotal || 0)
    } catch (e: any) {
      setError('Erreur: ' + e.message)
    } finally {
      setLoading(false)
    }
  }

  const kindLabel = (k: Row['kind']) => (k === 'pass' ? 'Pass' : k === 'free' ? 'Gratuit / inclus' : 'Vente')

  const exportCsv = () => {
    const header = ['Date', 'Edition', 'Concert', 'Tarif', 'Nature', 'Acheteur', 'Email', 'Canal', 'Prix']
    const lines = rows.map((r) => [
      r.date, r.eventName, r.concert, r.ticket, kindLabel(r.kind), r.buyer, r.email, r.channel, r.price.toFixed(2),
    ])
    const csv = [header, ...lines]
      .map((row) => row.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(';'))
      .join('\n')
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `comptabilite_${start}_${end}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <DashboardShell>
      <div className="p-4 sm:p-6 md:p-10">
        <div className="mb-6">
          <h2 className="text-xl md:text-2xl" style={{ fontWeight: 700, color: '#1a1a1a' }}>Comptabilité</h2>
          <p style={{ fontSize: '14px', color: '#888', marginTop: '4px' }}>
            Ventes (source Billetweb) et virements reçus — tout l&apos;historique
          </p>
        </div>

        {/* Filtres */}
        <div className="flex flex-wrap items-end gap-3 mb-2">
          <div>
            <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '4px' }}>Édition</label>
            <select value={edition} onChange={(e) => setEdition(e.target.value)}
              className="px-3 py-2 rounded-lg text-sm" style={{ border: '1px solid #ddd', background: '#fff', minWidth: '170px' }}>
              <option value="">Toutes les éditions</option>
              {editions.map((ed) => <option key={ed} value={ed}>{ed}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '4px' }}>Du</label>
            <DatePicker value={start} max={end || todayIso} onChange={setStart} />
          </div>
          <div>
            <label style={{ fontSize: '12px', color: '#666', display: 'block', marginBottom: '4px' }}>Au</label>
            <DatePicker value={end} min={start} max={todayIso} onChange={setEnd} />
          </div>
          <button onClick={load} disabled={loading}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm"
            style={{ background: '#722f37', color: '#fff', border: 'none', fontWeight: 600, cursor: 'pointer' }}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            Charger
          </button>
          {rows.length > 0 && (
            <button onClick={exportCsv}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm"
              style={{ background: '#d4af37', color: '#1a1a1a', border: 'none', fontWeight: 600, cursor: 'pointer' }}>
              <Download className="w-4 h-4" />
              Exporter CSV
            </button>
          )}
        </div>
        <p style={{ fontSize: '12px', color: '#999', marginBottom: '20px' }}>
          Le total « Recettes » correspond exactement au « Prix » affiché par Billetweb (somme des ventes payées).
        </p>

        {error && (
          <div className="mb-4 rounded-lg p-3" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
            <p style={{ color: '#991b1b', fontSize: '13px', margin: 0 }}>{error}</p>
          </div>
        )}

        {/* Totaux */}
        {totals && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
              {[
                { label: 'Recettes (Prix Billetweb)', value: eur(totals.brut), color: '#722f37' },
                { label: 'Billets payés', value: String(totals.count), color: '#1a1a1a' },
                { label: 'Déjà reversé (banque)', value: eur(payoutTotal), color: '#166534' },
                { label: 'Reste à reverser', value: eur(totals.brut - payoutTotal), color: '#b87333' },
              ].map((c) => (
                <div key={c.label} className="rounded-xl p-4" style={{ background: '#fff', border: '1px solid #eee' }}>
                  <p style={{ fontSize: '11px', color: '#888', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{c.label}</p>
                  <p style={{ fontSize: '18px', fontWeight: 700, color: c.color }}>{c.value}</p>
                </div>
              ))}
            </div>
            <p style={{ fontSize: '13px', color: '#666', marginBottom: '24px' }}>
              <strong style={{ color: '#722f37' }}>{totals.saleCount}</strong> billets simples ·{' '}
              <strong style={{ color: '#722f37' }}>{totals.passCount}</strong> pass ·{' '}
              <strong style={{ color: '#888' }}>{totals.freeCount}</strong> gratuits / inclus (0 €)
            </p>
          </>
        )}

        {/* Tableau ventes */}
        {rows.length > 0 && (
          <div className="rounded-xl overflow-hidden mb-8" style={{ border: '1px solid #eee' }}>
            <div className="overflow-x-auto">
              <table className="w-full text-sm" style={{ borderCollapse: 'collapse', minWidth: '860px' }}>
                <thead>
                  <tr style={{ background: '#f7f3e9' }}>
                    {['Date', 'Édition', 'Concert', 'Tarif', 'Nature', 'Canal', 'Prix'].map((h) => (
                      <th key={h} style={{ textAlign: h === 'Prix' ? 'right' : 'left', padding: '10px 12px', fontWeight: 600, color: '#722f37', fontSize: '12px' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0, 800).map((r, i) => {
                    const badge = r.kind === 'pass'
                      ? { txt: 'Pass', bg: '#d4af37', fg: '#1a1a1a' }
                      : r.kind === 'free'
                      ? { txt: 'Gratuit', bg: '#eee', fg: '#666' }
                      : { txt: 'Vente', bg: '#e7f0e7', fg: '#166534' }
                    return (
                      <tr key={i} style={{ borderTop: '1px solid #f0f0f0' }}>
                        <td style={{ padding: '8px 12px', color: '#666', whiteSpace: 'nowrap' }}>{r.date}</td>
                        <td style={{ padding: '8px 12px', color: '#333' }}>{r.eventName}</td>
                        <td style={{ padding: '8px 12px', color: '#333' }}>{r.concert}</td>
                        <td style={{ padding: '8px 12px', color: '#666' }}>{r.ticket}</td>
                        <td style={{ padding: '8px 12px' }}>
                          <span style={{ background: badge.bg, color: badge.fg, fontSize: '11px', fontWeight: 600, padding: '2px 8px', borderRadius: '999px', whiteSpace: 'nowrap' }}>{badge.txt}</span>
                        </td>
                        <td style={{ padding: '8px 12px', color: '#666', fontSize: '12px' }}>{r.channel}</td>
                        <td style={{ padding: '8px 12px', textAlign: 'right', fontWeight: 600, color: '#333' }}>{eur(r.price)}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            {rows.length > 800 && (
              <p style={{ fontSize: '12px', color: '#888', padding: '10px 12px', margin: 0 }}>
                Affichage des 800 premières lignes ({totals?.count} au total). L&apos;export CSV contient tout.
              </p>
            )}
          </div>
        )}

        {/* Virements reçus */}
        {payouts.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#1a1a1a' }}>Virements reçus</h3>
              <span style={{ fontSize: '14px', fontWeight: 700, color: '#166534' }}>Total : {eur(payoutTotal)}</span>
            </div>
            <div className="rounded-xl overflow-hidden" style={{ border: '1px solid #eee' }}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm" style={{ borderCollapse: 'collapse', minWidth: '480px' }}>
                  <thead>
                    <tr style={{ background: '#f7f3e9' }}>
                      {['Date', 'Compte', 'IBAN', 'Montant'].map((h) => (
                        <th key={h} style={{ textAlign: h === 'Montant' ? 'right' : 'left', padding: '10px 12px', fontWeight: 600, color: '#722f37', fontSize: '12px' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {payouts.map((p, i) => (
                      <tr key={i} style={{ borderTop: '1px solid #f0f0f0' }}>
                        <td style={{ padding: '8px 12px', color: '#666', whiteSpace: 'nowrap' }}>{p.date}</td>
                        <td style={{ padding: '8px 12px', color: '#333' }}>{p.account}</td>
                        <td style={{ padding: '8px 12px', color: '#666', fontSize: '12px' }}>{p.iban}</td>
                        <td style={{ padding: '8px 12px', textAlign: 'right', fontWeight: 600, color: '#166534' }}>{eur(p.amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {!loading && rows.length === 0 && !error && (
          <p style={{ color: '#888', fontSize: '14px' }}>
            Choisis une édition/période et clique « Charger ».
          </p>
        )}
      </div>
    </DashboardShell>
  )
}
