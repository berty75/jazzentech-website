// PATH: src/components/DatePicker.tsx
'use client'

import { useEffect, useRef, useState } from 'react'
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react'

const MONTHS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre']
const DAYS = ['lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim']

const iso = (d: Date) => {
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}
const parse = (s: string) => {
  const [y, m, d] = s.split('-').map(Number)
  return new Date(y, (m || 1) - 1, d || 1)
}
const fmt = (s: string) => {
  if (!s) return 'JJ/MM/AAAA'
  const [y, m, d] = s.split('-')
  return `${d}/${m}/${y}`
}

export default function DatePicker({
  value,
  onChange,
  min,
  max,
}: {
  value: string
  onChange: (v: string) => void
  min?: string
  max?: string
}) {
  const [open, setOpen] = useState(false)
  const [view, setView] = useState(() => (value ? parse(value) : new Date()))
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (open && value) setView(parse(value))
  }, [open, value])

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    if (open) document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [open])

  const year = view.getFullYear()
  const month = view.getMonth()
  const firstDay = new Date(year, month, 1)
  // getDay(): 0=dim..6=sam → on veut lun=0
  const offset = (firstDay.getDay() + 6) % 7
  const daysInMonth = new Date(year, month + 1, 0).getDate()

  const cells: (number | null)[] = []
  for (let i = 0; i < offset; i++) cells.push(null)
  for (let d = 1; d <= daysInMonth; d++) cells.push(d)
  while (cells.length % 7 !== 0) cells.push(null)

  const disabled = (d: number) => {
    const cur = iso(new Date(year, month, d))
    if (min && cur < min) return true
    if (max && cur > max) return true
    return false
  }

  const select = (d: number) => {
    onChange(iso(new Date(year, month, d)))
    setOpen(false)
  }

  const todayStr = iso(new Date())

  return (
    <div ref={ref} style={{ position: 'relative', display: 'inline-block' }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm"
        style={{ border: '1px solid #ddd', background: '#fff', color: '#1a1a1a', cursor: 'pointer', minWidth: '150px' }}
      >
        <Calendar className="w-4 h-4" style={{ color: '#722f37' }} />
        {fmt(value)}
      </button>

      {open && (
        <div
          style={{
            position: 'absolute', top: 'calc(100% + 6px)', left: 0, zIndex: 50,
            background: '#fff', border: '1px solid #e8dfc8', borderRadius: '14px',
            boxShadow: '0 12px 32px rgba(26,26,26,0.18)', padding: '12px', width: '288px',
          }}
        >
          {/* En-tête mois */}
          <div className="flex items-center justify-between mb-2">
            <button type="button" onClick={() => setView(new Date(year, month - 1, 1))}
              className="p-1.5 rounded-lg" style={{ border: 'none', background: '#f7f3e9', cursor: 'pointer' }}>
              <ChevronLeft className="w-4 h-4" style={{ color: '#722f37' }} />
            </button>
            <span style={{ fontWeight: 700, color: '#722f37', fontSize: '14px', textTransform: 'capitalize' }}>
              {MONTHS[month]} {year}
            </span>
            <button type="button" onClick={() => setView(new Date(year, month + 1, 1))}
              className="p-1.5 rounded-lg" style={{ border: 'none', background: '#f7f3e9', cursor: 'pointer' }}>
              <ChevronRight className="w-4 h-4" style={{ color: '#722f37' }} />
            </button>
          </div>

          {/* Jours de la semaine */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: '2px', marginBottom: '4px' }}>
            {DAYS.map((d) => (
              <div key={d} style={{ textAlign: 'center', fontSize: '11px', color: '#b87333', fontWeight: 600, padding: '4px 0' }}>{d}</div>
            ))}
          </div>

          {/* Grille jours */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: '2px' }}>
            {cells.map((d, i) => {
              if (d === null) return <div key={i} />
              const cur = iso(new Date(year, month, d))
              const isSel = value === cur
              const isToday = todayStr === cur
              const off = disabled(d)
              return (
                <button
                  key={i}
                  type="button"
                  disabled={off}
                  onClick={() => select(d)}
                  style={{
                    aspectRatio: '1', border: 'none', borderRadius: '8px',
                    cursor: off ? 'not-allowed' : 'pointer',
                    background: isSel ? '#722f37' : 'transparent',
                    color: off ? '#ccc' : isSel ? '#fff' : '#1a1a1a',
                    fontWeight: isSel || isToday ? 700 : 400,
                    fontSize: '13px',
                    outline: isToday && !isSel ? '1px solid #d4af37' : 'none',
                  }}
                  onMouseEnter={(e) => { if (!off && !isSel) (e.target as HTMLElement).style.background = '#f7f3e9' }}
                  onMouseLeave={(e) => { if (!isSel) (e.target as HTMLElement).style.background = 'transparent' }}
                >
                  {d}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
