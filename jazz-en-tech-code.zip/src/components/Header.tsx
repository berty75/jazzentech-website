'use client'
import Link from 'next/link'
import Navigation from './Navigation'
import { Menu, X, Ticket } from 'lucide-react'
import { useState, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import Image from 'next/image'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const isHome = pathname === '/'
  const [isScrolled, setIsScrolled] = useState(false)
  const [isLandscape, setIsLandscape] = useState(false)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 200)
    const handleResize = () => {
      setIsLandscape(window.innerHeight < window.innerWidth && window.innerHeight < 600)
    }
    window.addEventListener('scroll', handleScroll)
    window.addEventListener('resize', handleResize)
    handleResize()
    return () => { window.removeEventListener('scroll', handleScroll); window.removeEventListener('resize', handleResize) }
  }, [])

  const getHeaderHeight = () => {
    if (isLandscape) return '3rem'
    if (isScrolled) return '5.5rem'
    return '5.5rem'
  }

  const getLogoHeight = () => {
    if (isLandscape) return '2rem'
    return '5rem'
  }

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: isScrolled || isMenuOpen ? '#722f37' : 'transparent',
        boxShadow: isScrolled ? '0 4px 20px rgba(0, 0, 0, 0.3)' : 'none',
        height: getHeaderHeight(),
      }}
    >
      <div className="container mx-auto px-4 h-full">
        <div className="flex items-center justify-between h-full">
          <Link href="/" className="nav-link flex items-center hover:opacity-90 transition-all duration-300 rounded-lg p-1 flex-shrink-0">
            <Image
              src="https://res.cloudinary.com/dpgfensnv/image/upload/f_auto,q_auto,w_800/jazz_en_tech_logo_smkogd.png"
              alt="Jazz en Tech Festival"
              width={200}
              height={104}
              className="w-auto transition-all duration-300"
              style={{
                height: getLogoHeight(),
                maxHeight: getLogoHeight(),
                opacity: !isScrolled ? 0 : 1,
                transition: 'opacity 0.3s',
              }}
              priority
            />
          </Link>

          <div className="hidden lg:flex items-center space-x-4 xl:space-x-6">
            <Navigation isScrolled={isScrolled} />
            <Link
              href="/billetterie"
              className="btn-primary flex items-center px-4 py-2 xl:px-6 xl:py-3 rounded-xl font-bold transition-all duration-500 transform hover:scale-105 animate-glow-pulse"
              style={{
                background: isScrolled ? 'linear-gradient(45deg, #d4af37, #b87333)' : '#1a1a1a',
                color: isScrolled ? '#1a1a1a' : '#d4af37',
                border: isScrolled ? '2px solid #d4af37' : '2px solid #1a1a1a',
              }}
            >
              <Ticket className="w-4 h-4 xl:w-5 xl:h-5 mr-1 xl:mr-2" />
              <span className="hidden xl:inline">Billetterie</span>
              <span className="xl:hidden">Billets</span>
            </Link>
          </div>

          <button
            className="lg:hidden text-white hover:text-yellow-300 transition-colors p-2 rounded-lg"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div
            className={`lg:hidden absolute left-0 right-0 border-t border-white/20 shadow-lg top-full`}
            style={{ backgroundColor: '#722f37', backdropFilter: 'blur(10px)', zIndex: 1000 }}
          >
            <div className={`container mx-auto px-4 ${isLandscape ? 'py-2' : 'py-4'}`}>
              <Navigation mobile onItemClick={() => setIsMenuOpen(false)} compact={isLandscape} />
              <div className={`border-t border-white/20 ${isLandscape ? 'mt-2 pt-2' : 'mt-4 pt-4'}`}>
                <Link
                  href="/billetterie"
                  onClick={() => setIsMenuOpen(false)}
                  className={`btn-primary flex items-center justify-center w-full rounded-xl font-bold transition-all duration-500 animate-glow-pulse ${isLandscape ? 'px-4 py-2 text-sm' : 'px-6 py-3'}`}
                  style={{ background: 'linear-gradient(45deg, #d4af37, #b87333)', color: '#1a1a1a', border: '2px solid #d4af37' }}
                >
                  <Ticket className={`mr-2 ${isLandscape ? 'w-4 h-4' : 'w-5 h-5'}`} />
                  <span>{isLandscape ? 'Billets' : 'Reserver mes billets'}</span>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}